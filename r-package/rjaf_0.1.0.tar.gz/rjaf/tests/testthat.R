library(testthat)
library(rjaf)

test_check("rjaf")
